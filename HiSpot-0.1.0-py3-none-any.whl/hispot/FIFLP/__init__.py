from .fiflp_max import MaFM
from .fiflp_min import MiFM
from .gop_max import MaAG
from .gop_min import MiFMG


